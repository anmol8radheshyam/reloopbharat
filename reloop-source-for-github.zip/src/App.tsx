import { useState, useEffect, useRef, useCallback } from "react";

// ─── DATA ───────────────────────────────────────────────────────────────────

const SUPPLY = [
  { id: "s1", company: "Metro Manufacturing", type: "Industry", material: "Aluminium Scrap", qty: 1800, grade: "Grade A", price: 142, distance: 38, status: "AI Matched", verified: true, matchScore: 96, allocatedQty: 1800 },
  { id: "s2", company: "GreenLoop Kabadi", type: "Kabadiwala", material: "Aluminium Scrap", qty: 900, grade: "Grade B+", price: 136, distance: 11, status: "Aggregation Ready", verified: true, matchScore: 88, allocatedQty: 900 },
  { id: "s3", company: "Urban Fabricators", type: "Small Business", material: "Aluminium Scrap", qty: 1100, grade: "Grade A", price: 145, distance: 24, status: "AI Matched", verified: true, matchScore: 91, allocatedQty: 1100 },
  { id: "s4", company: "Community Collection", type: "Household", material: "Aluminium Scrap", qty: 350, grade: "Grade B", price: 128, distance: 19, status: "Available", verified: false, matchScore: 52, allocatedQty: 0 },
  { id: "s5", company: "Prime Auto Components", type: "Industry", material: "Aluminium Scrap", qty: 1250, grade: "Grade A", price: 146, distance: 51, status: "AI Matched", verified: true, matchScore: 89, allocatedQty: 1200 },
  { id: "s6", company: "City Kabadi Hub", type: "Kabadiwala", material: "Mixed Metals", qty: 650, grade: "Grade B+", price: 119, distance: 16, status: "Available", verified: true, matchScore: 61, allocatedQty: 0 },
];

const DEMAND = [
  { id: "d1", company: "EcoMetal Recycling", material: "Aluminium Scrap", qty: 5000, grade: "Grade B+ or better", price: 148, deadline: "20 Sep", location: "North Manufacturing Cluster", fulfilled: 78, status: "AI Sourcing", verified: true },
  { id: "d2", company: "PolyCycle Materials", material: "PET Plastic", qty: 3200, grade: "Grade B+", price: 62, deadline: "18 Sep", location: "East Industrial Zone", fulfilled: 64, status: "AI Sourcing", verified: true },
  { id: "d3", company: "BuildGlass Industries", material: "Glass", qty: 8000, grade: "Grade B", price: 9, deadline: "25 Sep", location: "South Cluster", fulfilled: 42, status: "Active", verified: true },
  { id: "d4", company: "RenewTex Manufacturing", material: "Textile Waste", qty: 1500, grade: "Grade B+", price: 28, deadline: "22 Sep", location: "West Zone", fulfilled: 31, status: "Active", verified: false },
];

const TRANSACTIONS = [
  { id: "RL-2026-0841", material: "Aluminium Scrap", qty: 5000, buyer: "EcoMetal Recycling", value: "₹7.18L", status: "IN COLLECTION", progress: 68, stage: 6 },
  { id: "RL-2026-0837", material: "PET Plastic", qty: 3200, buyer: "PolyCycle Materials", value: "₹1.98L", status: "DELIVERED", progress: 100, stage: 9 },
  { id: "RL-2026-0831", material: "Glass", qty: 6400, buyer: "BuildGlass Industries", value: "₹57.6K", status: "AI MATCHED", progress: 32, stage: 3 },
];

const TX_STAGES = ["Posted", "AI Matched", "Optimized", "Batch Created", "Collection Assigned", "Picked Up", "In Transit", "Delivered", "Settled"];

const NAV_ITEMS = [
  { id: "home", label: "Home", icon: "⊙" },
  { id: "marketplace", label: "Marketplace", icon: "◫" },
  { id: "opportunities", label: "AI Opportunities", icon: "✦" },
  { id: "optimizer", label: "Optimizer", icon: "⬡" },
  { id: "logistics", label: "Logistics", icon: "⟳" },
  { id: "price", label: "Price Intelligence", icon: "◈" },
  { id: "network", label: "Network", icon: "⬡" },
  { id: "transactions", label: "Transactions", icon: "≡" },
  { id: "impact", label: "Impact", icon: "◉" },
];

// ─── HOOKS ──────────────────────────────────────────────────────────────────

function useAnimatedCounter(target: number, duration = 1200, start = true) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      setValue(Math.round(ease * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target, duration, start]);
  return value;
}

// ─── STATUS BADGE ────────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { cls: string; icon: string }> = {
    "AI Matched": { cls: "badge-purple", icon: "✦" },
    "Aggregation Ready": { cls: "badge-amber", icon: "⚡" },
    "Available": { cls: "badge-green", icon: "●" },
    "AI Sourcing": { cls: "badge-purple", icon: "✦" },
    "Active": { cls: "badge-blue", icon: "●" },
    "IN COLLECTION": { cls: "badge-amber", icon: "🚚" },
    "DELIVERED": { cls: "badge-green", icon: "✓" },
    "AI MATCHED": { cls: "badge-purple", icon: "✦" },
    "OPTIMIZING": { cls: "badge-purple", icon: "◉" },
    "OPTIMAL": { cls: "badge-green", icon: "✓" },
  };
  const cfg = map[status] || { cls: "badge-gray", icon: "●" };
  return <span className={`badge ${cfg.cls}`}>{cfg.icon} {status}</span>;
}

// ─── TOAST ───────────────────────────────────────────────────────────────────

function Toast({ message, onClose }: { message: string; onClose: () => void }) {
  useEffect(() => {
    const t = setTimeout(onClose, 3500);
    return () => clearTimeout(t);
  }, [onClose]);
  return (
    <div className="toast">
      <span style={{ color: "#10b981", fontSize: 18 }}>✓</span>
      <span style={{ color: "#e8edf5", fontSize: 14 }}>{message}</span>
    </div>
  );
}

// ─── ANIMATED COUNTER ────────────────────────────────────────────────────────

function AnimCounter({ value, suffix = "", prefix = "" }: { value: number; suffix?: string; prefix?: string }) {
  const count = useAnimatedCounter(value, 1400);
  return <span>{prefix}{count.toLocaleString("en-IN")}{suffix}</span>;
}

// ─── NETWORK SVG ─────────────────────────────────────────────────────────────

function NetworkGraph({ onNodeClick }: { onNodeClick: (node: string) => void }) {
  const nodes = [
    { id: "household", label: "Households", x: 80, y: 60, color: "#60a5fa" },
    { id: "business", label: "Businesses", x: 220, y: 30, color: "#34d399" },
    { id: "industry", label: "Industries", x: 360, y: 60, color: "#f59e0b" },
    { id: "kabadi", label: "Kabadiwalas", x: 80, y: 180, color: "#fb923c" },
    { id: "reloop", label: "RELOOP AI", x: 230, y: 155, color: "#7c3aed" },
    { id: "recycler", label: "Recyclers", x: 130, y: 290, color: "#10b981" },
    { id: "manufacturer", label: "Manufacturers", x: 330, y: 290, color: "#10b981" },
    { id: "collection", label: "Collection Partners", x: 230, y: 360, color: "#94a3b8" },
  ];

  const edges = [
    ["household", "reloop"], ["business", "reloop"], ["industry", "reloop"], ["kabadi", "reloop"],
    ["reloop", "recycler"], ["reloop", "manufacturer"],
    ["recycler", "collection"], ["manufacturer", "collection"],
  ];

  const getNode = (id: string) => nodes.find(n => n.id === id)!;

  return (
    <div style={{ position: "relative", width: "100%", maxWidth: 460, margin: "0 auto" }}>
      <svg viewBox="0 0 460 420" style={{ width: "100%", height: "auto" }}>
        <defs>
          <marker id="arrow" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
            <path d="M0,0 L6,3 L0,6 Z" fill="rgba(16,185,129,0.5)" />
          </marker>
          {edges.map(([a, b], i) => {
            const na = getNode(a); const nb = getNode(b);
            return (
              <linearGradient key={i} id={`grad${i}`} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor={na.color} stopOpacity="0.6" />
                <stop offset="100%" stopColor={nb.color} stopOpacity="0.6" />
              </linearGradient>
            );
          })}
        </defs>
        {edges.map(([a, b], i) => {
          const na = getNode(a); const nb = getNode(b);
          const len = Math.hypot(nb.x - na.x, nb.y - na.y);
          return (
            <line
              key={i}
              x1={na.x} y1={na.y} x2={nb.x} y2={nb.y}
              stroke={`url(#grad${i})`}
              strokeWidth="1.5"
              strokeDasharray={`${len * 0.6} ${len * 0.4}`}
              style={{ animation: `dash-flow ${2 + i * 0.3}s linear infinite` }}
              markerEnd="url(#arrow)"
            />
          );
        })}
        {nodes.map((n) => (
          <g key={n.id} onClick={() => onNodeClick(n.id)} style={{ cursor: "pointer" }}>
            <circle cx={n.x} cy={n.y} r={n.id === "reloop" ? 30 : 22} fill={`${n.color}22`} stroke={n.color} strokeWidth={n.id === "reloop" ? 2.5 : 1.5} />
            {n.id === "reloop" && <circle cx={n.x} cy={n.y} r={36} fill="none" stroke={n.color} strokeWidth={0.5} strokeOpacity={0.4} strokeDasharray="4 4" style={{ animation: "rotate-slow 8s linear infinite" }} />}
            <text x={n.x} y={n.y + 5} textAnchor="middle" fill={n.color} fontSize={n.id === "reloop" ? "7" : "6.5"} fontFamily="JetBrains Mono" fontWeight="600">{n.id === "reloop" ? "AI" : n.label.split(" ")[0]}</text>
            <text x={n.x} y={n.y + (n.id === "reloop" ? -38 : -28)} textAnchor="middle" fill="rgba(228,235,245,0.8)" fontSize="9" fontFamily="Inter">{n.label}</text>
          </g>
        ))}
      </svg>
    </div>
  );
}

// ─── NODE DETAIL ─────────────────────────────────────────────────────────────

const NODE_DATA: Record<string, { title: string; qty?: string; material?: string; price?: string; dist?: string; count?: string; desc: string }> = {
  household: { title: "Households", count: "128 households", desc: "Residential material sources. Small quantities, high aggregation potential.", material: "Paper, PET, Glass", qty: "15–50 kg avg" },
  business: { title: "Businesses", count: "46 businesses", desc: "SMEs and retail. Regular supply with better consistency than households.", material: "Cardboard, PET, Aluminium", qty: "100–500 kg avg" },
  industry: { title: "Industries", count: "18 industries", desc: "High-volume, high-quality material. Premium pricing and grade.", material: "Aluminium, Copper, Steel", qty: "500–2000 kg avg", price: "₹130–₹160/kg" },
  kabadi: { title: "Kabadiwalas", count: "12 kabadiwalas", desc: "Critical aggregation hubs — they collect, sort and pre-aggregate material, making them essential network nodes.", material: "Mixed metals, PET", qty: "200–1000 kg avg" },
  reloop: { title: "RELOOP AI", desc: "Central intelligence layer. Matches supply with demand, optimizes allocation, routes logistics, and coordinates collection.", qty: "5,700 kg active", price: "₹18.4L network value" },
  recycler: { title: "Recyclers", count: "9 recyclers", desc: "End buyers — process material into secondary raw materials.", qty: "1,000–10,000 kg demand" },
  manufacturer: { title: "Manufacturers", count: "12 manufacturers", desc: "Use recycled material as input in production — reduce raw material costs.", qty: "500–5,000 kg demand" },
  collection: { title: "Collection Partners", count: "12 partners", desc: "Logistics execution layer — pickup and transport. Optimized routes assigned by ReLoop AI.", qty: "126 km avg route", price: "₹3,240 avg trip" },
};

function NodePanel({ node, onClose }: { node: string; onClose: () => void }) {
  const d = NODE_DATA[node];
  if (!d) return null;
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" style={{ maxWidth: 380 }} onClick={e => e.stopPropagation()}>
        <button onClick={onClose} style={{ position: "absolute", top: 16, right: 16, background: "none", border: "none", color: "#64748b", cursor: "pointer", fontSize: 20 }}>×</button>
        <div className="badge badge-purple" style={{ marginBottom: 12 }}>Network Node</div>
        <h3 style={{ fontFamily: "Outfit", fontSize: 22, fontWeight: 700, marginBottom: 8 }}>{d.title}</h3>
        {d.count && <p style={{ color: "#10b981", fontSize: 13, marginBottom: 8, fontFamily: "JetBrains Mono" }}>{d.count}</p>}
        <p style={{ color: "#94a3b8", fontSize: 14, lineHeight: 1.6, marginBottom: 16 }}>{d.desc}</p>
        {d.material && <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 16 }}>
          {d.material.split(", ").map(m => <span key={m} className="badge badge-blue">{m}</span>)}
        </div>}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {d.qty && <div className="stat-card"><div style={{ fontSize: 11, color: "#64748b", marginBottom: 4, fontFamily: "JetBrains Mono" }}>QUANTITY</div><div style={{ fontSize: 16, fontWeight: 600, color: "#e8edf5" }}>{d.qty}</div></div>}
          {d.price && <div className="stat-card"><div style={{ fontSize: 11, color: "#64748b", marginBottom: 4, fontFamily: "JetBrains Mono" }}>PRICE</div><div style={{ fontSize: 16, fontWeight: 600, color: "#10b981" }}>{d.price}</div></div>}
        </div>
      </div>
    </div>
  );
}

// ─── HOME PAGE ───────────────────────────────────────────────────────────────

function HomePage({ onNav }: { onNav: (page: string) => void }) {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const kg = useAnimatedCounter(5700, 1200);
  const val = useAnimatedCounter(184, 1400);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, minHeight: "calc(100vh - 80px)", alignItems: "start", padding: "32px 0" }}>
      {/* Left: Hero */}
      <div style={{ display: "flex", flexDirection: "column", gap: 24, paddingTop: 20 }}>
        <div>
          <div className="badge badge-green animate-pulse-green" style={{ marginBottom: 16 }}>● RELOOP NETWORK LIVE</div>
          <h1 style={{ fontFamily: "Outfit", fontSize: "clamp(32px, 3.5vw, 52px)", fontWeight: 900, lineHeight: 1.1, marginBottom: 16, letterSpacing: "-0.02em" }}>
            Waste is scattered.<br />
            <span style={{ background: "linear-gradient(135deg, #10b981, #34d399)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Value is connected.</span>
          </h1>
          <p style={{ color: "#94a3b8", fontSize: 16, lineHeight: 1.7, marginBottom: 8, maxWidth: 480 }}>
            ReLoop connects fragmented material supply with real demand — then uses AI and optimization to find the smartest way to move it.
          </p>
          <p style={{ fontFamily: "JetBrains Mono", fontSize: 13, color: "#7c3aed", marginBottom: 28, fontStyle: "italic" }}>
            "ReLoop doesn't just find a match. It solves the allocation problem."
          </p>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 32 }}>
            <button className="btn-primary" style={{ fontSize: 15, padding: "13px 24px" }} onClick={() => onNav("addmaterial")}>+ I HAVE MATERIAL</button>
            <button className="btn-outline" style={{ fontSize: 15, padding: "13px 24px" }} onClick={() => onNav("createdemand")}>I NEED MATERIAL</button>
          </div>
        </div>

        {/* Live Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {[
            { label: "KG AVAILABLE", value: `${kg.toLocaleString("en-IN")}`, unit: "kg", color: "#10b981" },
            { label: "ACTIVE DEMANDS", value: "23", color: "#7c3aed" },
            { label: "COLLECTION PARTNERS", value: "12", color: "#f59e0b" },
            { label: "NETWORK VALUE", value: `₹${val.toLocaleString("en-IN")}L`, color: "#60a5fa" },
          ].map((s) => (
            <div key={s.label} className="stat-card" style={{ textAlign: "center" }}>
              <div style={{ fontSize: "clamp(22px, 2.5vw, 32px)", fontFamily: "Outfit", fontWeight: 800, color: s.color, lineHeight: 1 }}>{s.value}</div>
              <div style={{ fontSize: 11, color: "#64748b", marginTop: 6, fontFamily: "JetBrains Mono", letterSpacing: "0.5px" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Value Chain */}
        <div style={{ background: "rgba(124, 58, 237, 0.06)", border: "1px solid rgba(124, 58, 237, 0.15)", borderRadius: 12, padding: 20 }}>
          <div style={{ fontSize: 11, fontFamily: "JetBrains Mono", color: "#7c3aed", marginBottom: 12, letterSpacing: 1 }}>RELOOP IS</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {["Marketplace", "AI Matching", "Allocation Optimization", "Aggregation", "Logistics", "Settlement"].map((t, i) => (
              <span key={t}>
                <span className="badge badge-purple" style={{ fontSize: 12 }}>{t}</span>
                {i < 5 && <span style={{ color: "#4b5563", margin: "0 2px" }}>+</span>}
              </span>
            ))}
          </div>
        </div>

        <div style={{ display: "flex", gap: 12 }}>
          <button className="btn-outline" onClick={() => onNav("opportunities")}>View AI Opportunities</button>
          <button className="btn-outline" onClick={() => onNav("optimizer")}>Run Optimizer →</button>
        </div>
      </div>

      {/* Right: Network Graph */}
      <div style={{ background: "rgba(12, 20, 40, 0.6)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24, position: "sticky", top: 24 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div>
            <div style={{ fontFamily: "Outfit", fontWeight: 700, fontSize: 16 }}>Network Topology</div>
            <div style={{ fontSize: 12, color: "#64748b" }}>Click any node to explore</div>
          </div>
          <div className="badge badge-green animate-pulse-green">LIVE</div>
        </div>
        <NetworkGraph onNodeClick={setSelectedNode} />
        <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap", marginTop: 12 }}>
          {[{ c: "#60a5fa", l: "Supply" }, { c: "#7c3aed", l: "AI" }, { c: "#10b981", l: "Demand" }, { c: "#94a3b8", l: "Logistics" }].map(d => (
            <div key={d.l} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 11, color: "#64748b" }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: d.c }} />
              {d.l}
            </div>
          ))}
        </div>
      </div>

      {selectedNode && <NodePanel node={selectedNode} onClose={() => setSelectedNode(null)} />}
    </div>
  );
}

// ─── MARKETPLACE ─────────────────────────────────────────────────────────────

function MarketplacePage({ onNav }: { onNav: (page: string) => void }) {
  const [tab, setTab] = useState<"supply" | "demand">("supply");
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [toast, setToast] = useState<string | null>(null);

  const filtered = SUPPLY.filter(s =>
    (search === "" || s.company.toLowerCase().includes(search.toLowerCase()) || s.material.toLowerCase().includes(search.toLowerCase())) &&
    (filter === "all" || s.type.toLowerCase().includes(filter))
  );

  return (
    <div style={{ padding: "32px 0" }}>
      {toast && <Toast message={toast} onClose={() => setToast(null)} />}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>Marketplace</div>
          <div style={{ color: "#64748b", fontSize: 14 }}>Material supply and demand network — not just listings, but live opportunities</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn-primary" onClick={() => onNav("addmaterial")}>+ Add Material</button>
          <button className="btn-outline" onClick={() => onNav("createdemand")}>+ Create Demand</button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 4, background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 10, padding: 4, marginBottom: 20, width: "fit-content" }}>
        {(["supply", "demand"] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ padding: "8px 24px", borderRadius: 7, border: "none", cursor: "pointer", fontWeight: 600, fontSize: 14, transition: "all 0.2s", background: tab === t ? (t === "supply" ? "rgba(16,185,129,0.15)" : "rgba(124,58,237,0.15)") : "transparent", color: tab === t ? (t === "supply" ? "#10b981" : "#a78bfa") : "#64748b" }}>
            {t.charAt(0).toUpperCase() + t.slice(1)} {t === "supply" ? `(${SUPPLY.length})` : `(${DEMAND.length})`}
          </button>
        ))}
      </div>

      {/* Search & Filter */}
      <div style={{ display: "flex", gap: 12, marginBottom: 24, flexWrap: "wrap" }}>
        <input
          value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Search materials, companies..."
          style={{ flex: 1, minWidth: 240, background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "10px 16px", color: "#e8edf5", fontSize: 14, outline: "none" }}
        />
        {["all", "industry", "business", "kabadi", "household"].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{ padding: "8px 16px", borderRadius: 8, border: `1px solid ${filter === f ? "rgba(16,185,129,0.4)" : "rgba(255,255,255,0.07)"}`, background: filter === f ? "rgba(16,185,129,0.1)" : "rgba(12,20,40,0.8)", color: filter === f ? "#10b981" : "#64748b", cursor: "pointer", fontSize: 13, fontWeight: 500, transition: "all 0.2s" }}>
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {/* Cards */}
      {tab === "supply" ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
          {filtered.map((s) => (
            <div key={s.id} className="supply-card" onClick={() => onNav("opportunities")}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 2 }}>{s.company}</div>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    <span className="badge badge-gray">{s.type}</span>
                    {s.verified && <span className="badge badge-green">✓ Verified</span>}
                  </div>
                </div>
                <StatusBadge status={s.status} />
              </div>

              <div style={{ fontFamily: "Outfit", fontSize: 18, fontWeight: 800, color: "#e8edf5", marginBottom: 12 }}>{s.material}</div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 8, marginBottom: 14 }}>
                {[
                  { l: "QTY", v: `${s.qty.toLocaleString("en-IN")} kg` },
                  { l: "GRADE", v: s.grade },
                  { l: "PRICE", v: `₹${s.price}/kg` },
                  { l: "DIST", v: `${s.distance} km` },
                ].map(d => (
                  <div key={d.l}>
                    <div style={{ fontSize: 10, color: "#64748b", fontFamily: "JetBrains Mono" }}>{d.l}</div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "#e8edf5" }}>{d.v}</div>
                  </div>
                ))}
              </div>

              {s.status !== "Available" && (
                <>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 11, color: "#64748b", fontFamily: "JetBrains Mono" }}>AI MATCH SCORE</span>
                    <span style={{ fontSize: 13, fontWeight: 700, color: s.matchScore > 85 ? "#10b981" : "#f59e0b" }}>{s.matchScore}%</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{ width: `${s.matchScore}%`, background: s.matchScore > 85 ? "linear-gradient(90deg, #10b981, #34d399)" : "linear-gradient(90deg, #f59e0b, #fcd34d)" }} />
                  </div>
                </>
              )}

              <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
                <button className="btn-outline" style={{ flex: 1, justifyContent: "center", padding: "8px" }} onClick={e => { e.stopPropagation(); onNav("opportunities"); }}>View</button>
                <button className="btn-primary" style={{ flex: 1, justifyContent: "center", padding: "8px" }} onClick={e => { e.stopPropagation(); setToast(`${s.company} added to batch`); }}>+ Add to Batch</button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
          {DEMAND.map((d) => (
            <div key={d.id} className="demand-card" onClick={() => onNav("createdemand")}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 4 }}>{d.company}</div>
                  {d.verified && <span className="badge badge-green">✓ Verified</span>}
                </div>
                <StatusBadge status={d.status} />
              </div>
              <div style={{ fontSize: 12, color: "#64748b", marginBottom: 4, fontFamily: "JetBrains Mono" }}>NEEDS</div>
              <div style={{ fontFamily: "Outfit", fontSize: 18, fontWeight: 800, marginBottom: 12 }}>{d.material}</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
                <div><div style={{ fontSize: 10, color: "#64748b", fontFamily: "JetBrains Mono" }}>QUANTITY</div><div style={{ fontSize: 14, fontWeight: 700 }}>{d.qty.toLocaleString("en-IN")} kg</div></div>
                <div><div style={{ fontSize: 10, color: "#64748b", fontFamily: "JetBrains Mono" }}>GRADE</div><div style={{ fontSize: 13, fontWeight: 600 }}>{d.grade}</div></div>
                <div><div style={{ fontSize: 10, color: "#64748b", fontFamily: "JetBrains Mono" }}>TARGET</div><div style={{ fontSize: 14, fontWeight: 700, color: "#10b981" }}>₹{d.price}/kg</div></div>
                <div><div style={{ fontSize: 10, color: "#64748b", fontFamily: "JetBrains Mono" }}>DEADLINE</div><div style={{ fontSize: 13, fontWeight: 600, color: "#f59e0b" }}>{d.deadline}</div></div>
              </div>
              <div style={{ fontSize: 12, color: "#64748b", marginBottom: 6, fontFamily: "JetBrains Mono" }}>📍 {d.location}</div>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: 11, color: "#64748b", fontFamily: "JetBrains Mono" }}>FULFILMENT</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: "#10b981" }}>{d.fulfilled}%</span>
              </div>
              <div className="progress-bar" style={{ marginBottom: 14 }}>
                <div className="progress-fill" style={{ width: `${d.fulfilled}%`, background: "linear-gradient(90deg, #10b981, #34d399)" }} />
              </div>
              <button className="btn-ai" style={{ width: "100%", justifyContent: "center" }} onClick={e => { e.stopPropagation(); onNav("optimizer"); }}>✦ Find Supply</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── AI OPPORTUNITIES ────────────────────────────────────────────────────────

function OpportunitiesPage({ onNav }: { onNav: (page: string) => void }) {
  const [selected, setSelected] = useState<string | null>(null);

  const opps = [
    {
      id: "bulk", type: "BULK MATCH", icon: "⬡", color: "#10b981", title: "5,000 kg Aluminium Demand Matchable",
      stats: [{ l: "Network Supply", v: "5,700 kg" }, { l: "Demand", v: "5,000 kg" }, { l: "Fulfilment Potential", v: "100%" }, { l: "AI Confidence", v: "94%" }],
      desc: "Network supply exceeds demand. Full fulfilment achievable without compromise.",
      action: "Run Optimizer",
    },
    {
      id: "aggregation", type: "AGGREGATION OPPORTUNITY", icon: "⚡", color: "#f59e0b", title: "4 Fragmented Suppliers → 1 Batch",
      stats: [{ l: "Suppliers", v: "4" }, { l: "Total Supply", v: "5,000 kg" }, { l: "Demand Gap", v: "Covered" }, { l: "AI Confidence", v: "94%" }],
      desc: "Aggregate Metro Manufacturing (1,800 kg) + Urban Fabricators (1,100 kg) + GreenLoop Kabadi (900 kg) + Prime Auto Components (1,200 kg)",
      action: "View Detail",
    },
    {
      id: "price", type: "PRICE OPPORTUNITY", icon: "◈", color: "#60a5fa", title: "₹5.4/kg Margin Available",
      stats: [{ l: "Supplier Avg", v: "₹142.6/kg" }, { l: "Buyer Target", v: "₹148/kg" }, { l: "Spread", v: "₹5.4/kg" }, { l: "Total Value", v: "₹27,000" }],
      desc: "Buyer willing to pay significantly above supplier average. Strong transaction margin available.",
      action: "View Pricing",
    },
    {
      id: "logistics", type: "LOGISTICS OPPORTUNITY", icon: "⟳", color: "#a78bfa", title: "31% Logistics Cost Saving",
      stats: [{ l: "Pickup Points", v: "3" }, { l: "Baseline Cost", v: "₹4,690" }, { l: "Optimized Cost", v: "₹3,240" }, { l: "Saving", v: "₹1,450" }],
      desc: "Optimized route combining 3 pickups into a single vehicle run. 126 km route vs 182 km baseline.",
      action: "View Route",
    },
    {
      id: "urgent", type: "URGENT DEMAND", icon: "⏱", color: "#f87171", title: "EcoMetal deadline in 8 days",
      stats: [{ l: "Deadline", v: "20 Sep" }, { l: "Demand", v: "5,000 kg" }, { l: "Currently Filled", v: "78%" }, { l: "Gap Remaining", v: "1,100 kg" }],
      desc: "Time-sensitive. Must collect and deliver before September 20. Logistics window narrowing.",
      action: "Activate",
    },
  ];

  return (
    <div style={{ padding: "32px 0" }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>AI Opportunity Radar</div>
        <div style={{ color: "#94a3b8", fontSize: 14 }}>ReLoop continuously searches the network for hidden economic opportunities</div>
        <div className="badge badge-purple" style={{ marginTop: 8 }}>AI Decision Engine • Prototype Simulation</div>
      </div>

      {/* Big CTA */}
      <div style={{ background: "linear-gradient(135deg, rgba(124,58,237,0.15), rgba(16,185,129,0.08))", border: "1px solid rgba(124,58,237,0.25)", borderRadius: 16, padding: 28, marginBottom: 28, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16 }}>
        <div>
          <div style={{ fontFamily: "Outfit", fontSize: 20, fontWeight: 800, marginBottom: 6 }}>🎯 5,000 kg Aluminium Opportunity Ready</div>
          <div style={{ color: "#94a3b8", fontSize: 14 }}>Full aggregation, allocation, and logistics plan available. Run the AI engine to see the complete solution.</div>
        </div>
        <button className="btn-ai" style={{ fontSize: 16, padding: "14px 32px" }} onClick={() => onNav("optimizer")}>✦ RUN RELOOP AI</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 16 }}>
        {opps.map((o) => (
          <div key={o.id} className="opportunity-card" onClick={() => setSelected(o.id === selected ? null : o.id)} style={{ borderColor: selected === o.id ? o.color + "44" : undefined, background: selected === o.id ? `${o.color}08` : undefined }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <div style={{ width: 38, height: 38, borderRadius: 10, background: `${o.color}20`, border: `1px solid ${o.color}40`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, color: o.color }}>{o.icon}</div>
                <div>
                  <div style={{ fontSize: 10, color: "#64748b", fontFamily: "JetBrains Mono", letterSpacing: 0.5 }}>{o.type}</div>
                  <div style={{ fontSize: 15, fontWeight: 700 }}>{o.title}</div>
                </div>
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 14 }}>
              {o.stats.map(s => (
                <div key={s.l} style={{ background: "rgba(255,255,255,0.03)", borderRadius: 8, padding: "8px 10px" }}>
                  <div style={{ fontSize: 10, color: "#64748b", fontFamily: "JetBrains Mono" }}>{s.l}</div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: o.color }}>{s.v}</div>
                </div>
              ))}
            </div>

            <p style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.6, marginBottom: 14 }}>{o.desc}</p>

            <button className="btn-primary" style={{ width: "100%", justifyContent: "center", background: `linear-gradient(135deg, ${o.color}, ${o.color}cc)` }}
              onClick={e => { e.stopPropagation(); if (o.action.includes("Optimizer") || o.action.includes("Run")) onNav("optimizer"); else if (o.action.includes("Route") || o.action.includes("Log")) onNav("logistics"); else if (o.action.includes("Pricing")) onNav("price"); else onNav("optimizer"); }}>
              {o.action} →
            </button>
          </div>
        ))}
      </div>

      {/* Aggregation detail */}
      {selected === "aggregation" && (
        <div style={{ marginTop: 24, background: "rgba(245,158,11,0.06)", border: "1px solid rgba(245,158,11,0.2)", borderRadius: 16, padding: 24 }}>
          <div style={{ fontFamily: "Outfit", fontSize: 18, fontWeight: 800, marginBottom: 4 }}>AI identified an aggregation opportunity</div>
          <div style={{ color: "#94a3b8", fontSize: 13, marginBottom: 20 }}>Buyer: EcoMetal Recycling — 5,000 kg Aluminium Scrap, Grade B+ or better</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 12, marginBottom: 20 }}>
            {SUPPLY.filter(s => s.allocatedQty > 0).map(s => (
              <div key={s.id} style={{ background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.2)", borderRadius: 10, padding: 14 }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{s.company}</div>
                <div style={{ fontSize: 20, fontWeight: 800, color: "#f59e0b" }}>{s.allocatedQty.toLocaleString("en-IN")} kg</div>
                <div style={{ fontSize: 12, color: "#94a3b8" }}>₹{s.price}/kg • {s.grade}</div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: 20, alignItems: "center", background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 10, padding: 16 }}>
            {[{ l: "Network Available", v: "5,700 kg", c: "#94a3b8" }, { l: "→ Demand", v: "5,000 kg", c: "#10b981" }, { l: "→ Reserve", v: "700 kg", c: "#64748b" }].map(d => (
              <div key={d.l} style={{ textAlign: "center" }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: d.c }}>{d.v}</div>
                <div style={{ fontSize: 11, color: "#64748b", fontFamily: "JetBrains Mono" }}>{d.l}</div>
              </div>
            ))}
            <div style={{ marginLeft: "auto" }}><div className="badge badge-green" style={{ fontSize: 13 }}>AI Confidence: 94%</div></div>
          </div>
          <button className="btn-ai" style={{ marginTop: 16 }} onClick={() => onNav("optimizer")}>✦ Run Full Optimizer</button>
        </div>
      )}
    </div>
  );
}

// ─── AI PROCESSING ANIMATION ─────────────────────────────────────────────────

function AIProcessing({ onComplete }: { onComplete: () => void }) {
  const [stage, setStage] = useState(0);
  const [subItems, setSubItems] = useState<string[]>([]);

  const stages = [
    { label: "UNDERSTANDING NETWORK...", items: ["Scanning supply listings", "Scanning active demands", "Loading network topology"], duration: 700 },
    { label: "CHECKING MATERIAL COMPATIBILITY...", items: ["✓ Material type", "✓ Quantity", "✓ Quality grade", "✓ Location", "✓ Availability"], duration: 900 },
    { label: "GENERATING FEASIBLE MATCHES...", items: ["27 possible connections found", "8 feasible combinations"], duration: 700 },
    { label: "SOLVING ALLOCATION...", items: ["Evaluating material cost", "Evaluating collection cost", "Evaluating transport cost", "Evaluating distance & deadline"], duration: 900 },
    { label: "OPTIMIZING LOGISTICS...", items: ["Evaluating pickup sequences", "Checking vehicle capacity", "Computing aggregation options", "Minimizing route cost"], duration: 700 },
    { label: "✓ OPTIMAL PLAN FOUND", items: ["5,000 kg demand fulfilled — 100%", "4 suppliers selected", "3 pickups consolidated", "31% logistics saving achieved"], duration: 500 },
  ];

  useEffect(() => {
    let timeout: ReturnType<typeof setTimeout>;
    const runStage = (s: number) => {
      if (s >= stages.length) { setTimeout(onComplete, 400); return; }
      setStage(s);
      setSubItems([]);
      const st = stages[s];
      st.items.forEach((item, i) => {
        timeout = setTimeout(() => {
          setSubItems(prev => [...prev, item]);
        }, (i + 1) * (st.duration / (st.items.length + 1)));
      });
      timeout = setTimeout(() => runStage(s + 1), st.duration + 200);
    };
    runStage(0);
    return () => clearTimeout(timeout);
  }, []);

  return (
    <div style={{ textAlign: "center", padding: "8px 0" }}>
      <div style={{ width: 80, height: 80, borderRadius: "50%", background: "rgba(124,58,237,0.15)", border: "2px solid #7c3aed", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px", position: "relative" }} className="animate-ai-pulse">
        <div style={{ fontSize: 28, animation: "rotate-slow 2s linear infinite" }}>✦</div>
      </div>
      <div style={{ fontFamily: "JetBrains Mono", fontSize: 11, color: "#7c3aed", letterSpacing: 2, marginBottom: 8 }}>RELOOP AI ENGINE</div>
      <div style={{ marginBottom: 24 }}>
        {stages.map((s, i) => (
          <div key={i} className={`ai-stage ${i === stage ? "active" : i < stage ? "done" : ""}`} style={{ opacity: i > stage ? 0.3 : 1 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 14 }}>{i < stage ? "✓" : i === stage ? <span className="animate-spin" style={{ display: "inline-block" }}>◌</span> : "○"}</span>
              <span style={{ fontSize: 13, fontFamily: "JetBrains Mono", fontWeight: 600, color: i === stage ? "#a78bfa" : i < stage ? "#10b981" : "#4b5563" }}>STAGE {i + 1}: {s.label}</span>
            </div>
            {i === stage && subItems.length > 0 && (
              <div style={{ paddingLeft: 22, marginTop: 6 }}>
                {subItems.map((item, j) => (
                  <div key={j} style={{ fontSize: 12, color: "#94a3b8", padding: "2px 0", animation: "slide-in-up 0.3s ease" }}>{item}</div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      <div style={{ fontSize: 12, color: "#4b5563", fontFamily: "JetBrains Mono" }}>AI Decision Engine • Prototype Simulation</div>
    </div>
  );
}

// ─── OPTIMIZER ────────────────────────────────────────────────────────────────

function OptimizerPage() {
  const [phase, setPhase] = useState<"input" | "running" | "result">("input");
  const [showWhy, setShowWhy] = useState(false);

  const allocated = SUPPLY.filter(s => s.allocatedQty > 0);
  const totalAllocated = allocated.reduce((sum, s) => sum + s.allocatedQty, 0);

  return (
    <div style={{ padding: "32px 0" }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 6 }}>
          <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800 }}>ReLoop Optimization Engine</div>
          <span className="badge badge-purple">AI + LP/MILP + ROUTING</span>
        </div>
        <div style={{ color: "#64748b", fontSize: 14 }}>Intelligent allocation: minimize total landed cost while satisfying all constraints</div>
      </div>

      {phase === "input" && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
          {/* Input */}
          <div>
            <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 24, marginBottom: 16 }}>
              <div className="badge badge-blue" style={{ marginBottom: 12 }}>BUYER DEMAND</div>
              <div style={{ fontFamily: "Outfit", fontSize: 20, fontWeight: 800, marginBottom: 4 }}>EcoMetal Recycling</div>
              {[{ l: "Material", v: "Aluminium Scrap" }, { l: "Quantity", v: "5,000 kg" }, { l: "Min Grade", v: "Grade B+" }, { l: "Target Price", v: "₹148/kg" }, { l: "Deadline", v: "20 September 2026" }].map(d => (
                <div key={d.l} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                  <span style={{ color: "#64748b", fontSize: 13 }}>{d.l}</span>
                  <span style={{ fontSize: 14, fontWeight: 600 }}>{d.v}</span>
                </div>
              ))}
            </div>

            <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 24, marginBottom: 16 }}>
              <div className="badge badge-green" style={{ marginBottom: 12 }}>NETWORK STATUS</div>
              {[{ l: "Total Available", v: "5,700 kg", c: "#10b981" }, { l: "Potential Suppliers", v: "6", c: "#e8edf5" }, { l: "Possible Connections", v: "27", c: "#e8edf5" }, { l: "Feasible Combinations", v: "8", c: "#e8edf5" }].map(d => (
                <div key={d.l} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                  <span style={{ color: "#64748b", fontSize: 13 }}>{d.l}</span>
                  <span style={{ fontSize: 14, fontWeight: 700, color: d.c }}>{d.v}</span>
                </div>
              ))}
            </div>

            <button className="btn-ai" style={{ width: "100%", justifyContent: "center", fontSize: 16, padding: "16px" }} onClick={() => setPhase("running")}>✦ RUN RELOOP AI</button>
          </div>

          {/* Mathematical Model */}
          <div style={{ background: "rgba(124,58,237,0.06)", border: "1px solid rgba(124,58,237,0.15)", borderRadius: 12, padding: 24 }}>
            <div className="badge badge-purple" style={{ marginBottom: 16 }}>MATHEMATICAL MODEL</div>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 12, color: "#a78bfa", marginBottom: 6 }}>Decision Variables</div>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 14, color: "#e8edf5", marginBottom: 20, padding: "10px 14px", background: "rgba(124,58,237,0.1)", borderRadius: 8 }}>
              xᵢⱼ = quantity transported<br />from supplier i to buyer j
            </div>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 12, color: "#a78bfa", marginBottom: 6 }}>Objective Function</div>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 13, color: "#e8edf5", marginBottom: 20, padding: "10px 14px", background: "rgba(124,58,237,0.1)", borderRadius: 8, lineHeight: 1.8 }}>
              MINIMIZE:<br />
              Σ (material_cost × xᵢⱼ)<br />
              + Σ (collection_cost × xᵢⱼ)<br />
              + Σ (transport_cost × xᵢⱼ)<br />
              + Σ (handling_cost × xᵢⱼ)
            </div>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 12, color: "#a78bfa", marginBottom: 6 }}>Constraints</div>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 13, color: "#e8edf5", padding: "10px 14px", background: "rgba(124,58,237,0.1)", borderRadius: 8, lineHeight: 2 }}>
              Supply: Σⱼ xᵢⱼ ≤ Sᵢ ∀i<br />
              Demand: Σᵢ xᵢⱼ ≥ Dⱼ ∀j<br />
              Non-neg: xᵢⱼ ≥ 0 ∀i,j
            </div>
          </div>
        </div>
      )}

      {phase === "running" && (
        <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(124,58,237,0.3)", borderRadius: 16, padding: 32, maxWidth: 560, margin: "0 auto" }}>
          <AIProcessing onComplete={() => setPhase("result")} />
        </div>
      )}

      {phase === "result" && (
        <div style={{ animation: "slide-in-up 0.5s ease" }}>
          {/* Hero result */}
          <div style={{ background: "linear-gradient(135deg, rgba(16,185,129,0.12), rgba(124,58,237,0.08))", border: "1px solid rgba(16,185,129,0.25)", borderRadius: 16, padding: 28, marginBottom: 24, textAlign: "center" }}>
            <div className="badge badge-green" style={{ marginBottom: 12, fontSize: 13 }}>✓ OPTIMAL PLAN FOUND</div>
            <div style={{ fontFamily: "Outfit", fontSize: 18, fontWeight: 700, color: "#94a3b8", marginBottom: 4 }}>DEMAND FULFILLED</div>
            <div style={{ fontFamily: "Outfit", fontSize: "clamp(48px, 6vw, 72px)", fontWeight: 900, color: "#10b981", lineHeight: 1 }}>
              <AnimCounter value={5000} /> KG
            </div>
            <div style={{ fontFamily: "Outfit", fontSize: 32, fontWeight: 800, color: "#34d399" }}>100%</div>
            <div style={{ display: "flex", gap: 24, justifyContent: "center", marginTop: 20, flexWrap: "wrap" }}>
              {[{ v: "4", l: "SUPPLIERS" }, { v: "3", l: "PICKUPS" }, { v: "31%", l: "LOGISTICS SAVING" }, { v: "94%", l: "AI CONFIDENCE" }].map(d => (
                <div key={d.l} style={{ textAlign: "center" }}>
                  <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, color: "#f59e0b" }}>{d.v}</div>
                  <div style={{ fontSize: 11, color: "#64748b", fontFamily: "JetBrains Mono" }}>{d.l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Allocation table */}
          <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 24, marginBottom: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <div style={{ fontFamily: "Outfit", fontSize: 18, fontWeight: 700 }}>Selected Allocation</div>
              <div className="badge badge-green">OPTIMAL</div>
            </div>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
                    {["Supplier", "Type", "Grade", "Price/kg", "Allocated", "Status"].map(h => (
                      <th key={h} style={{ padding: "8px 12px", textAlign: "left", fontSize: 11, color: "#64748b", fontFamily: "JetBrains Mono", fontWeight: 600 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {allocated.map((s, i) => (
                    <tr key={s.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.04)", animation: `slide-in-up 0.4s ease ${i * 0.1}s both` }}>
                      <td style={{ padding: "12px 12px", fontWeight: 600 }}>{s.company}</td>
                      <td style={{ padding: "12px 12px" }}><span className="badge badge-gray" style={{ fontSize: 11 }}>{s.type}</span></td>
                      <td style={{ padding: "12px 12px", color: "#94a3b8", fontSize: 13 }}>{s.grade}</td>
                      <td style={{ padding: "12px 12px", color: "#10b981", fontWeight: 700 }}>₹{s.price}</td>
                      <td style={{ padding: "12px 12px", fontFamily: "JetBrains Mono", fontWeight: 700, fontSize: 15 }}>{s.allocatedQty.toLocaleString("en-IN")} kg</td>
                      <td style={{ padding: "12px 12px" }}><span className="badge badge-green">SELECTED</span></td>
                    </tr>
                  ))}
                  <tr style={{ borderTop: "2px solid rgba(16,185,129,0.3)", background: "rgba(16,185,129,0.05)" }}>
                    <td colSpan={4} style={{ padding: "12px 12px", fontWeight: 700, color: "#10b981" }}>TOTAL ALLOCATED</td>
                    <td style={{ padding: "12px 12px", fontFamily: "JetBrains Mono", fontWeight: 800, fontSize: 18, color: "#10b981" }}>{totalAllocated.toLocaleString("en-IN")} kg</td>
                    <td><span className="badge badge-green">= DEMAND ✓</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Constraints satisfied */}
          <div style={{ background: "rgba(16,185,129,0.06)", border: "1px solid rgba(16,185,129,0.15)", borderRadius: 12, padding: 20, marginBottom: 16 }}>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 11, color: "#10b981", marginBottom: 12, letterSpacing: 1 }}>CONSTRAINT VERIFICATION</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 8 }}>
              {["Supply constraint satisfied", "Demand constraint satisfied (5,000 kg)", "Capacity constraint satisfied", "Grade constraint satisfied (B+)", "Deadline constraint satisfied (20 Sep)", "xᵢⱼ ≥ 0 satisfied"].map(c => (
                <div key={c} style={{ display: "flex", gap: 8, alignItems: "center", fontSize: 13, color: "#34d399" }}>
                  <span>✓</span> {c}
                </div>
              ))}
            </div>
          </div>

          {/* Reserve visualization */}
          <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 20, marginBottom: 16 }}>
            <div style={{ display: "flex", gap: 0, height: 40, borderRadius: 8, overflow: "hidden", marginBottom: 10 }}>
              <div style={{ flex: 5000, background: "linear-gradient(90deg, #10b981, #34d399)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: "white" }}>5,000 kg (Demand)</div>
              <div style={{ flex: 700, background: "rgba(100,116,139,0.4)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 600, color: "#94a3b8" }}>700 kg (Reserve)</div>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#64748b", fontFamily: "JetBrains Mono" }}>
              <span>Total Network: 5,700 kg</span>
              <span style={{ color: "#10b981" }}>Demand: 5,000 kg</span>
              <span>Reserve: 700 kg</span>
            </div>
          </div>

          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <button className="btn-primary" style={{ fontSize: 15, padding: "13px 28px" }} onClick={() => setShowWhy(true)}>WHY DID RELOOP CHOOSE THIS?</button>
            <button className="btn-outline" onClick={() => setPhase("input")}>← Reset</button>
          </div>
        </div>
      )}

      {/* Explainability modal */}
      {showWhy && (
        <div className="modal-overlay" onClick={() => setShowWhy(false)}>
          <div className="modal-content" style={{ maxWidth: 620 }} onClick={e => e.stopPropagation()}>
            <button onClick={() => setShowWhy(false)} style={{ position: "absolute", top: 16, right: 16, background: "none", border: "none", color: "#64748b", cursor: "pointer", fontSize: 20 }}>×</button>
            <div className="badge badge-purple" style={{ marginBottom: 12 }}>EXPLAINABILITY</div>
            <div style={{ fontFamily: "Outfit", fontSize: 22, fontWeight: 800, marginBottom: 4 }}>Why ReLoop Selected These Suppliers</div>
            <div style={{ color: "#64748b", fontSize: 13, marginBottom: 20 }}>AI Decision Engine • Prototype Simulation</div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 20 }}>
              {["Material compatible (Aluminium Scrap)", "Required quality available (Grade B+)", "Quantity sufficient (5,000 kg)", "Competitive material price (₹142–₹146/kg)", "Collection distance optimized", "Supplier reliability verified", "Vehicle capacity matched", "Delivery deadline satisfied (20 Sep)", "Aggregation feasible (3 pickups)", "Total landed cost minimized"].map(r => (
                <div key={r} style={{ display: "flex", gap: 8, alignItems: "flex-start", fontSize: 13, color: "#34d399" }}>
                  <span style={{ flexShrink: 0 }}>✓</span><span>{r}</span>
                </div>
              ))}
            </div>

            <div style={{ background: "rgba(124,58,237,0.08)", border: "1px solid rgba(124,58,237,0.2)", borderRadius: 10, padding: 16, marginBottom: 20 }}>
              <div style={{ fontFamily: "JetBrains Mono", fontSize: 11, color: "#7c3aed", marginBottom: 8 }}>OPTIMIZATION OBJECTIVE</div>
              <div style={{ textAlign: "center", fontFamily: "JetBrains Mono", fontSize: 14, color: "#a78bfa", lineHeight: 2 }}>
                MINIMIZE TOTAL LANDED COST<br />
                = Material Cost + Collection Cost<br />
                + Transport Cost + Handling Cost
              </div>
            </div>

            <div style={{ fontFamily: "Outfit", fontSize: 16, fontWeight: 700, marginBottom: 12 }}>Rejected Alternatives</div>
            <div style={{ background: "rgba(239,68,68,0.06)", border: "1px solid rgba(239,68,68,0.15)", borderRadius: 10, padding: 16 }}>
              <div style={{ fontWeight: 600, marginBottom: 4 }}>Community Collection — 350 kg</div>
              <div style={{ color: "#f87171", fontSize: 13, marginBottom: 8 }}><span className="badge badge-red">NOT SELECTED</span></div>
              {["Lower verification/reliability (unverified)", "Additional pickup complexity (19 km detour)", "Lower economic advantage (₹128/kg vs ₹136–₹146)", "Not required — demand already satisfied from 4 suppliers"].map(r => (
                <div key={r} style={{ display: "flex", gap: 8, fontSize: 13, color: "#94a3b8", marginBottom: 4 }}>
                  <span style={{ color: "#f87171" }}>•</span>{r}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── LOGISTICS ────────────────────────────────────────────────────────────────

function LogisticsPage() {
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentStop, setCurrentStop] = useState(0);
  const [toast, setToast] = useState<string | null>(null);

  const stops = [
    { name: "Metro Manufacturing", qty: "1,800 kg", time: "10:20 AM", x: 10, y: 30, type: "pickup" },
    { name: "GreenLoop Kabadi", qty: "900 kg", time: "11:15 AM", x: 35, y: 20, type: "pickup" },
    { name: "Urban Fabricators", qty: "1,100 kg", time: "12:10 PM", x: 60, y: 50, type: "pickup" },
    { name: "EcoMetal Recycling", qty: "5,000 kg", time: "14:00 PM", x: 85, y: 30, type: "delivery" },
  ];

  const startRoute = () => {
    setRunning(true);
    setProgress(0);
    setCurrentStop(0);
    let p = 0;
    const interval = setInterval(() => {
      p += 0.8;
      setProgress(Math.min(p, 100));
      setCurrentStop(Math.floor((p / 100) * (stops.length - 1)));
      if (p >= 100) {
        clearInterval(interval);
        setRunning(false);
        setToast("Route completed! All pickups done. Delivery in progress.");
      }
    }, 60);
  };

  return (
    <div style={{ padding: "32px 0" }}>
      {toast && <Toast message={toast} onClose={() => setToast(null)} />}
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>Logistics Optimizer</div>
        <div style={{ color: "#64748b", fontSize: 14 }}>Optimized collection route — 3 pickups, 1 delivery</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        {/* Route Map Simulation */}
        <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 24 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div style={{ fontFamily: "Outfit", fontSize: 16, fontWeight: 700 }}>Route Map</div>
            <span className="badge badge-purple">AI Optimized</span>
          </div>

          {/* Route visualization */}
          <div style={{ position: "relative", height: 200, background: "rgba(124,58,237,0.04)", border: "1px solid rgba(124,58,237,0.1)", borderRadius: 10, marginBottom: 20, overflow: "hidden" }}>
            {/* Grid lines */}
            {[...Array(5)].map((_, i) => (
              <div key={i} style={{ position: "absolute", left: 0, right: 0, top: `${20 * i}%`, height: "1px", background: "rgba(255,255,255,0.03)" }} />
            ))}

            <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }} viewBox="0 0 400 200">
              {/* Route path */}
              <polyline
                points={stops.map(s => `${s.x * 4},${s.y * 2}`).join(" ")}
                fill="none"
                stroke="rgba(16,185,129,0.4)"
                strokeWidth="2"
                strokeDasharray="8 4"
                style={running ? { animation: "dash-flow 1s linear infinite" } : {}}
              />
              {/* Completed route */}
              {running && (
                <polyline
                  points={stops.slice(0, currentStop + 1).map(s => `${s.x * 4},${s.y * 2}`).join(" ")}
                  fill="none"
                  stroke="rgba(16,185,129,0.9)"
                  strokeWidth="2.5"
                />
              )}
              {/* Stops */}
              {stops.map((s, i) => (
                <g key={i}>
                  <circle cx={s.x * 4} cy={s.y * 2} r={i <= currentStop && running ? 8 : 6} fill={s.type === "delivery" ? "#7c3aed" : (i <= currentStop && running ? "#10b981" : "#1e2d47")} stroke={s.type === "delivery" ? "#a78bfa" : "#10b981"} strokeWidth="2" />
                  <text x={s.x * 4} y={s.y * 2 - 12} textAnchor="middle" fill="#94a3b8" fontSize="8" fontFamily="Inter">{s.name.split(" ")[0]}</text>
                </g>
              ))}
              {/* Vehicle */}
              {running && (
                <circle cx={(progress / 100) * 340 + 40} cy={55} r="6" fill="#f59e0b" stroke="#fcd34d" strokeWidth="2">
                  <animateMotion dur="0.1s" />
                </circle>
              )}
            </svg>

            {/* Legend */}
            <div style={{ position: "absolute", bottom: 8, right: 8, display: "flex", gap: 8, fontSize: 10, color: "#64748b" }}>
              <span style={{ color: "#10b981" }}>● Pickup</span>
              <span style={{ color: "#7c3aed" }}>● Delivery</span>
              {running && <span style={{ color: "#f59e0b" }}>● Vehicle</span>}
            </div>
          </div>

          {/* Progress */}
          {running && (
            <div style={{ marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: 13, color: "#94a3b8" }}>Route Progress</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: "#10b981" }}>{Math.round(progress)}%</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${progress}%`, background: "linear-gradient(90deg, #10b981, #34d399)", transition: "width 0.1s linear" }} />
              </div>
            </div>
          )}

          <div style={{ display: "flex", gap: 10 }}>
            <button className="btn-outline" style={{ flex: 1, justifyContent: "center" }} onClick={() => setToast("Collection Partner #17 assigned to route")}>Assign Partner #17</button>
            <button className="btn-primary" style={{ flex: 1, justifyContent: "center" }} onClick={startRoute} disabled={running}>
              {running ? "En Route..." : "▶ Start Route"}
            </button>
          </div>
        </div>

        {/* Route stats + stops */}
        <div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
            {[
              { l: "VEHICLE CAPACITY", v: "5,000 kg", c: "#e8edf5" },
              { l: "UTILIZATION", v: "92%", c: "#10b981" },
              { l: "TOTAL DISTANCE", v: "126 km", c: "#e8edf5" },
              { l: "EST. TIME", v: "4h 18m", c: "#e8edf5" },
            ].map(d => (
              <div key={d.l} className="stat-card">
                <div style={{ fontSize: 10, color: "#64748b", fontFamily: "JetBrains Mono", marginBottom: 4 }}>{d.l}</div>
                <div style={{ fontFamily: "Outfit", fontSize: 22, fontWeight: 800, color: d.c }}>{d.v}</div>
              </div>
            ))}
          </div>

          {/* Cost comparison */}
          <div style={{ background: "rgba(16,185,129,0.06)", border: "1px solid rgba(16,185,129,0.15)", borderRadius: 12, padding: 16, marginBottom: 16 }}>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 11, color: "#10b981", marginBottom: 12, letterSpacing: 1 }}>LOGISTICS COST ANALYSIS</div>
            {[{ l: "Baseline Cost", v: "₹4,690", c: "#f87171", bar: 100 }, { l: "Optimized Cost", v: "₹3,240", c: "#10b981", bar: 69 }].map(d => (
              <div key={d.l} style={{ marginBottom: 10 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                  <span style={{ fontSize: 13 }}>{d.l}</span>
                  <span style={{ fontSize: 14, fontWeight: 700, color: d.c }}>{d.v}</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${d.bar}%`, background: d.c }} />
                </div>
              </div>
            ))}
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8, padding: "8px 12px", background: "rgba(16,185,129,0.1)", borderRadius: 8 }}>
              <span style={{ fontSize: 13, fontWeight: 600 }}>Estimated Saving</span>
              <span style={{ fontSize: 16, fontWeight: 800, color: "#10b981" }}>₹1,450 (31%)</span>
            </div>
          </div>

          {/* Stop list */}
          <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 20 }}>
            <div style={{ fontFamily: "Outfit", fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Collection Partner #17 — Today's Plan</div>
            {stops.map((s, i) => (
              <div key={i} className="route-stop" style={{ marginBottom: i < stops.length - 1 ? 24 : 0 }}>
                <div style={{ width: 32, height: 32, borderRadius: "50%", flexShrink: 0, background: s.type === "delivery" ? "rgba(124,58,237,0.2)" : (running && i <= currentStop ? "rgba(16,185,129,0.3)" : "rgba(30,45,71,0.8)"), border: `2px solid ${s.type === "delivery" ? "#7c3aed" : "#10b981"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: s.type === "delivery" ? "#a78bfa" : "#10b981" }}>{i + 1}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 2 }}>{s.name}</div>
                  <div style={{ color: "#94a3b8", fontSize: 13, marginBottom: 4 }}>{s.qty} • {s.time}</div>
                  <span className={`badge ${s.type === "delivery" ? "badge-purple" : "badge-green"}`}>{s.type === "delivery" ? "Delivery" : "Pickup"}</span>
                </div>
                {running && i <= currentStop && <span style={{ color: "#10b981", fontSize: 16 }}>✓</span>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── PRICE INTELLIGENCE ──────────────────────────────────────────────────────

function PricePage() {
  const [material, setMaterial] = useState("Aluminium");

  const materials: Record<string, { supplier: number; buyer: number; collection: number; transport: number; min: number; max: number }> = {
    Aluminium: { supplier: 142.6, buyer: 148, collection: 1.8, transport: 0.6, min: 128, max: 162 },
    Copper: { supplier: 485, buyer: 510, collection: 2.5, transport: 1.2, min: 460, max: 540 },
    PET: { supplier: 58, buyer: 64, collection: 1.2, transport: 0.4, min: 48, max: 70 },
    Paper: { supplier: 12, buyer: 14, collection: 0.8, transport: 0.3, min: 8, max: 18 },
    Glass: { supplier: 7.5, buyer: 9, collection: 0.6, transport: 0.5, min: 5, max: 12 },
    Textile: { supplier: 24, buyer: 28, collection: 1.0, transport: 0.5, min: 18, max: 35 },
  };

  const d = materials[material];
  const landed = d.supplier + d.collection + d.transport;
  const spread = d.buyer - d.supplier;

  return (
    <div style={{ padding: "32px 0" }}>
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>Price Intelligence</div>
        <div style={{ color: "#64748b", fontSize: 14 }}>Indicative market intelligence — prototype simulation</div>
      </div>

      {/* Material selector */}
      <div style={{ display: "flex", gap: 8, marginBottom: 28, flexWrap: "wrap" }}>
        {Object.keys(materials).map(m => (
          <button key={m} onClick={() => setMaterial(m)} style={{ padding: "10px 20px", borderRadius: 8, border: `1px solid ${material === m ? "rgba(16,185,129,0.5)" : "rgba(255,255,255,0.07)"}`, background: material === m ? "rgba(16,185,129,0.12)" : "rgba(12,20,40,0.8)", color: material === m ? "#10b981" : "#64748b", cursor: "pointer", fontWeight: 600, fontSize: 14, transition: "all 0.2s" }}>{m}</button>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <div>
          {/* Price range bar */}
          <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 24, marginBottom: 16 }}>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 11, color: "#64748b", marginBottom: 8 }}>INDICATIVE RANGE</div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontFamily: "JetBrains Mono", fontSize: 16, fontWeight: 700 }}>
              <span>₹{d.min}</span><span>₹{d.max}/kg</span>
            </div>
            <div style={{ position: "relative", height: 20, background: "rgba(255,255,255,0.05)", borderRadius: 10 }}>
              <div style={{ position: "absolute", left: `${((d.supplier - d.min) / (d.max - d.min)) * 100}%`, transform: "translateX(-50%)", top: -4 }}>
                <div style={{ width: 12, height: 28, background: "#10b981", borderRadius: 4 }} />
                <div style={{ fontSize: 10, color: "#10b981", whiteSpace: "nowrap", textAlign: "center", marginTop: 4 }}>Supplier</div>
              </div>
              <div style={{ position: "absolute", left: `${((d.buyer - d.min) / (d.max - d.min)) * 100}%`, transform: "translateX(-50%)", top: -4 }}>
                <div style={{ width: 12, height: 28, background: "#7c3aed", borderRadius: 4 }} />
                <div style={{ fontSize: 10, color: "#7c3aed", whiteSpace: "nowrap", textAlign: "center", marginTop: 4 }}>Buyer</div>
              </div>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
            {[
              { l: "Supplier Average", v: `₹${d.supplier}/kg`, c: "#10b981" },
              { l: "Buyer Target", v: `₹${d.buyer}/kg`, c: "#7c3aed" },
              { l: "Collection Cost", v: `₹${d.collection}/kg`, c: "#f59e0b" },
              { l: "Transport Cost", v: `₹${d.transport}/kg`, c: "#60a5fa" },
            ].map(s => (
              <div key={s.l} className="stat-card">
                <div style={{ fontSize: 11, color: "#64748b", fontFamily: "JetBrains Mono", marginBottom: 4 }}>{s.l}</div>
                <div style={{ fontFamily: "Outfit", fontSize: 20, fontWeight: 800, color: s.c }}>{s.v}</div>
              </div>
            ))}
          </div>

          <div style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 12, padding: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <span>Estimated Landed Cost</span>
              <span style={{ fontWeight: 800, fontSize: 18, color: "#10b981" }}>₹{landed.toFixed(1)}/kg</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span>Buyer Margin</span>
              <span style={{ fontWeight: 700, color: spread > 0 ? "#10b981" : "#f87171" }}>₹{spread.toFixed(1)}/kg {spread > 0 ? "▲" : "▼"}</span>
            </div>
          </div>
        </div>

        <div>
          {/* Factors */}
          <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 24, marginBottom: 16 }}>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 11, color: "#64748b", marginBottom: 16 }}>PRICE FACTORS</div>
            {[
              { factor: "Material Quality", impact: "High", dir: "up", desc: "Grade A commands 6–10% premium" },
              { factor: "Quantity", impact: "Medium", dir: "down", desc: "Bulk orders lower per-unit cost" },
              { factor: "Distance", impact: "Medium", dir: "up", desc: "+₹0.5/kg per 10 km above 20 km" },
              { factor: "Demand Urgency", impact: "High", dir: "up", desc: "Tight deadlines push buyer price up" },
              { factor: "Market Demand", impact: "High", dir: "up", desc: "Active recycler demand sustains price" },
            ].map(f => (
              <div key={f.factor} style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", padding: "10px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{f.factor}</div>
                  <div style={{ fontSize: 11, color: "#64748b" }}>{f.desc}</div>
                </div>
                <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                  <span style={{ fontSize: 11, color: f.dir === "up" ? "#10b981" : "#60a5fa" }}>{f.dir === "up" ? "↑" : "↓"}</span>
                  <span className={`badge ${f.impact === "High" ? "badge-amber" : "badge-blue"}`}>{f.impact}</span>
                </div>
              </div>
            ))}
          </div>

          <div style={{ padding: 12, background: "rgba(245,158,11,0.06)", border: "1px solid rgba(245,158,11,0.15)", borderRadius: 8, fontSize: 12, color: "#f59e0b" }}>
            ⚠ Indicative market intelligence — prototype simulation. Not live market data.
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── NETWORK PAGE ─────────────────────────────────────────────────────────────

function NetworkPage() {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const stats = [
    { l: "Industries", v: "18", c: "#f59e0b" }, { l: "Businesses", v: "46", c: "#34d399" },
    { l: "Households", v: "128", c: "#60a5fa" }, { l: "Kabadiwalas", v: "12", c: "#fb923c" },
    { l: "Recyclers", v: "9", c: "#10b981" }, { l: "Manufacturers", v: "12", c: "#10b981" },
    { l: "Collection Partners", v: "12", c: "#94a3b8" }, { l: "Total Nodes", v: "237", c: "#e8edf5" },
  ];

  return (
    <div style={{ padding: "32px 0" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 }}>
        <div>
          <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>ReLoop Network</div>
          <div style={{ color: "#64748b", fontSize: 14 }}>Circular supply network — all active nodes and connections</div>
        </div>
        <div className="badge badge-green animate-pulse-green">● 237 NODES ACTIVE</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 28 }}>
        {stats.map(s => (
          <div key={s.l} className="stat-card" style={{ textAlign: "center" }}>
            <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, color: s.c }}>{s.v}</div>
            <div style={{ fontSize: 12, color: "#64748b", fontFamily: "JetBrains Mono" }}>{s.l}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 24 }}>
          <div style={{ fontFamily: "Outfit", fontSize: 16, fontWeight: 700, marginBottom: 4 }}>Network Topology</div>
          <div style={{ fontSize: 12, color: "#64748b", marginBottom: 16 }}>Click any node to view details</div>
          <NetworkGraph onNodeClick={setSelectedNode} />
        </div>

        <div>
          <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 24, marginBottom: 16 }}>
            <div style={{ fontFamily: "Outfit", fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Kabadiwala Integration</div>
            <div style={{ background: "rgba(251,146,60,0.08)", border: "1px solid rgba(251,146,60,0.2)", borderRadius: 10, padding: 16, marginBottom: 12 }}>
              <div className="badge badge-amber" style={{ marginBottom: 8 }}>MATERIAL BANK</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                {[{ m: "Aluminium", v: "900 kg" }, { m: "Copper", v: "240 kg" }, { m: "PET", v: "1,200 kg" }, { m: "Cardboard", v: "650 kg" }].map(i => (
                  <div key={i.m} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "6px 0" }}>
                    <span style={{ color: "#94a3b8" }}>{i.m}</span>
                    <span style={{ fontWeight: 700, color: "#fb923c" }}>{i.v}</span>
                  </div>
                ))}
              </div>
            </div>
            <div style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 10, padding: 16 }}>
              <div className="badge badge-green" style={{ marginBottom: 8 }}>AGGREGATION HUB ROLE</div>
              <div style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.6 }}>
                ReLoop doesn't compete with kabadiwalas. They become critical aggregation nodes — collecting, sorting, and pre-aggregating material, making them essential to the circular supply chain.
              </div>
            </div>
          </div>

          <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 24 }}>
            <div style={{ fontFamily: "Outfit", fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Network Flow</div>
            {["WASTE (Fragmented)", "DISCOVERY (AI Scan)", "AGGREGATION (Kabadiwalas)", "MATCHING (AI Engine)", "OPTIMIZATION (LP/MILP)", "COLLECTION (Partners)", "RECYCLING (Buyers)", "NEW VALUE"].map((step, i, arr) => (
              <div key={step} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: i < arr.length - 1 ? 4 : 0 }}>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                  <div style={{ width: 10, height: 10, borderRadius: "50%", background: i === 0 ? "#f87171" : i === arr.length - 1 ? "#10b981" : "#7c3aed", flexShrink: 0 }} />
                  {i < arr.length - 1 && <div style={{ width: 2, height: 16, background: "linear-gradient(to bottom, #7c3aed44, #7c3aed22)" }} />}
                </div>
                <div style={{ fontSize: 13, color: i === 0 ? "#f87171" : i === arr.length - 1 ? "#10b981" : "#94a3b8", fontWeight: i === 0 || i === arr.length - 1 ? 700 : 500 }}>{step}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {selectedNode && <NodePanel node={selectedNode} onClose={() => setSelectedNode(null)} />}
    </div>
  );
}

// ─── TRANSACTIONS ─────────────────────────────────────────────────────────────

function TransactionsPage() {
  const [selected, setSelected] = useState<typeof TRANSACTIONS[0] | null>(null);

  return (
    <div style={{ padding: "32px 0" }}>
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>Transactions</div>
        <div style={{ color: "#64748b", fontSize: 14 }}>End-to-end transaction tracking from posting to settlement</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 16, marginBottom: 24 }}>
        {TRANSACTIONS.map(tx => (
          <div key={tx.id} className="supply-card" onClick={() => setSelected(tx)}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
              <div style={{ fontFamily: "JetBrains Mono", fontSize: 13, color: "#7c3aed" }}>{tx.id}</div>
              <StatusBadge status={tx.status} />
            </div>
            <div style={{ fontFamily: "Outfit", fontSize: 18, fontWeight: 800, marginBottom: 8 }}>{tx.material}</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 12 }}>
              <div><div style={{ fontSize: 10, color: "#64748b", fontFamily: "JetBrains Mono" }}>QTY</div><div style={{ fontSize: 13, fontWeight: 700 }}>{tx.qty.toLocaleString("en-IN")} kg</div></div>
              <div><div style={{ fontSize: 10, color: "#64748b", fontFamily: "JetBrains Mono" }}>BUYER</div><div style={{ fontSize: 12, fontWeight: 600 }}>{tx.buyer.split(" ")[0]}</div></div>
              <div><div style={{ fontSize: 10, color: "#64748b", fontFamily: "JetBrains Mono" }}>VALUE</div><div style={{ fontSize: 13, fontWeight: 700, color: "#10b981" }}>{tx.value}</div></div>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <span style={{ fontSize: 11, color: "#64748b", fontFamily: "JetBrains Mono" }}>PROGRESS</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: "#10b981" }}>{tx.progress}%</span>
            </div>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: `${tx.progress}%`, background: tx.progress === 100 ? "linear-gradient(90deg, #10b981, #34d399)" : "linear-gradient(90deg, #7c3aed, #a78bfa)" }} />
            </div>
          </div>
        ))}
      </div>

      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal-content" style={{ maxWidth: 560 }} onClick={e => e.stopPropagation()}>
            <button onClick={() => setSelected(null)} style={{ position: "absolute", top: 16, right: 16, background: "none", border: "none", color: "#64748b", cursor: "pointer", fontSize: 20 }}>×</button>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 13, color: "#7c3aed", marginBottom: 4 }}>{selected.id}</div>
            <div style={{ fontFamily: "Outfit", fontSize: 22, fontWeight: 800, marginBottom: 4 }}>{selected.material}</div>
            <div style={{ color: "#94a3b8", fontSize: 14, marginBottom: 24 }}>{selected.qty.toLocaleString("en-IN")} kg → {selected.buyer} • {selected.value}</div>

            <div style={{ position: "relative" }}>
              {TX_STAGES.map((stage, i) => {
                const done = i < selected.stage;
                const current = i === selected.stage - 1;
                return (
                  <div key={stage} style={{ display: "flex", gap: 16, marginBottom: i < TX_STAGES.length - 1 ? 4 : 0 }}>
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                      <div style={{ width: 28, height: 28, borderRadius: "50%", background: done ? "rgba(16,185,129,0.2)" : current ? "rgba(245,158,11,0.2)" : "rgba(30,45,71,0.8)", border: `2px solid ${done ? "#10b981" : current ? "#f59e0b" : "#1e2d47"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, color: done ? "#10b981" : current ? "#f59e0b" : "#4b5563", flexShrink: 0 }}>
                        {done ? "✓" : current ? "●" : i + 1}
                      </div>
                      {i < TX_STAGES.length - 1 && <div style={{ width: 2, height: 20, background: done ? "rgba(16,185,129,0.4)" : "rgba(30,45,71,0.8)" }} />}
                    </div>
                    <div style={{ paddingBottom: i < TX_STAGES.length - 1 ? 20 : 0 }}>
                      <div style={{ fontSize: 14, fontWeight: current ? 700 : done ? 600 : 400, color: done ? "#34d399" : current ? "#f59e0b" : "#4b5563" }}>{stage}</div>
                      {current && <div className="badge badge-amber" style={{ marginTop: 4 }}>CURRENT</div>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── IMPACT ───────────────────────────────────────────────────────────────────

function ImpactPage() {
  const recovered = useAnimatedCounter(24800, 1400);
  const value = useAnimatedCounter(184, 1400);
  const diversion = useAnimatedCounter(127, 1400);

  return (
    <div style={{ padding: "32px 0" }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>ReLoop Impact</div>
        <div style={{ color: "#64748b", fontSize: 14 }}>Measuring the circular economy in motion</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 28 }}>
        {[
          { v: `${recovered.toLocaleString("en-IN")} kg`, l: "Material Recovered", c: "#10b981", icon: "♻" },
          { v: `₹${value.toLocaleString("en-IN")}L`, l: "Transaction Value", c: "#7c3aed", icon: "₹" },
          { v: "31%", l: "Logistics Optimization", c: "#f59e0b", icon: "⟳" },
          { v: `${(diversion / 10).toFixed(1)} t`, l: "Material Diverted from Waste", c: "#60a5fa", icon: "◉" },
          { v: "18", l: "Industrial Suppliers", c: "#e8edf5", icon: "⬡" },
          { v: "9", l: "Recycling Buyers", c: "#e8edf5", icon: "◈" },
        ].map(s => (
          <div key={s.l} className="stat-card" style={{ textAlign: "center", padding: 28 }}>
            <div style={{ fontSize: 28, marginBottom: 8 }}>{s.icon}</div>
            <div style={{ fontFamily: "Outfit", fontSize: "clamp(24px, 3vw, 36px)", fontWeight: 900, color: s.c, marginBottom: 4 }}>{s.v}</div>
            <div style={{ fontSize: 13, color: "#64748b" }}>{s.l}</div>
          </div>
        ))}
      </div>

      {/* Flow diagram */}
      <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 28, marginBottom: 24 }}>
        <div style={{ fontFamily: "Outfit", fontSize: 18, fontWeight: 700, marginBottom: 20, textAlign: "center" }}>The Circular Value Chain</div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", flexWrap: "wrap", gap: 4 }}>
          {[
            { label: "WASTE", color: "#f87171", desc: "Fragmented" },
            { label: "DISCOVERY", color: "#60a5fa", desc: "AI Scan" },
            { label: "AGGREGATION", color: "#fb923c", desc: "Kabadiwalas" },
            { label: "OPTIMIZATION", color: "#7c3aed", desc: "LP/MILP" },
            { label: "COLLECTION", color: "#f59e0b", desc: "Logistics" },
            { label: "RECYCLING", color: "#34d399", desc: "Buyers" },
            { label: "NEW VALUE", color: "#10b981", desc: "Circular" },
          ].map((step, i, arr) => (
            <div key={step.label} style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <div style={{ textAlign: "center", minWidth: 80 }}>
                <div style={{ background: `${step.color}20`, border: `1px solid ${step.color}40`, borderRadius: 10, padding: "10px 14px", marginBottom: 4 }}>
                  <div style={{ fontFamily: "JetBrains Mono", fontSize: 10, fontWeight: 700, color: step.color, letterSpacing: 0.5 }}>{step.label}</div>
                </div>
                <div style={{ fontSize: 10, color: "#4b5563" }}>{step.desc}</div>
              </div>
              {i < arr.length - 1 && <div style={{ color: "#1e2d47", fontSize: 20, flexShrink: 0 }}>→</div>}
            </div>
          ))}
        </div>
      </div>

      {/* Per-material breakdown */}
      <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 24 }}>
        <div style={{ fontFamily: "Outfit", fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Material Recovery Breakdown</div>
        {[
          { m: "Aluminium Scrap", qty: 5000, pct: 72, color: "#10b981" },
          { m: "PET Plastic", qty: 3200, pct: 46, color: "#60a5fa" },
          { m: "Glass", qty: 6400, pct: 80, color: "#94a3b8" },
          { m: "Mixed Metals", qty: 650, pct: 9, color: "#fb923c" },
          { m: "Textile Waste", qty: 465, pct: 6, color: "#f59e0b" },
        ].map(d => (
          <div key={d.m} style={{ marginBottom: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <span style={{ fontSize: 14, fontWeight: 600 }}>{d.m}</span>
              <div style={{ display: "flex", gap: 12 }}>
                <span style={{ fontSize: 13, color: "#94a3b8" }}>{d.qty.toLocaleString("en-IN")} kg</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: d.color }}>{d.pct}%</span>
              </div>
            </div>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: `${d.pct}%`, background: d.color }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── ADD MATERIAL ──────────────────────────────────────────────────────────────

function AddMaterialPage() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ material: "Aluminium Scrap", qty: "", grade: "Grade A", price: "", location: "", availability: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div style={{ padding: "32px 0", maxWidth: 520, margin: "0 auto" }}>
        <div style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.25)", borderRadius: 16, padding: 32, textAlign: "center" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>✓</div>
          <div style={{ fontFamily: "Outfit", fontSize: 24, fontWeight: 800, color: "#10b981", marginBottom: 8 }}>Material Posted</div>
          <div style={{ color: "#94a3b8", marginBottom: 24 }}>ReLoop AI is scanning the network...</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 24 }}>
            <div className="stat-card"><div style={{ fontSize: 22, fontWeight: 800, color: "#10b981" }}>3</div><div style={{ fontSize: 12, color: "#64748b" }}>Potential buyers found</div></div>
            <div className="stat-card"><div style={{ fontSize: 22, fontWeight: 800, color: "#f59e0b" }}>1</div><div style={{ fontSize: 12, color: "#64748b" }}>Aggregation opportunity</div></div>
          </div>
          <button className="btn-primary" style={{ width: "100%", justifyContent: "center" }} onClick={() => setSubmitted(false)}>Post Another</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: "32px 0", maxWidth: 520, margin: "0 auto" }}>
      <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>Add Material</div>
      <div style={{ color: "#64748b", fontSize: 14, marginBottom: 24 }}>List your material — ReLoop AI will immediately scan for buyers and opportunities</div>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        {[
          { label: "Material Type", key: "material", options: ["Aluminium Scrap", "Copper", "PET Plastic", "Paper", "Glass", "Textile Waste", "Mixed Metals"] },
          { label: "Grade", key: "grade", options: ["Grade A", "Grade B+", "Grade B", "Grade C"] },
        ].map(f => (
          <div key={f.key}>
            <label style={{ fontSize: 13, color: "#94a3b8", display: "block", marginBottom: 6 }}>{f.label}</label>
            <select value={form[f.key as keyof typeof form]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
              style={{ width: "100%", background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "11px 14px", color: "#e8edf5", fontSize: 14 }}>
              {f.options.map(o => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>
        ))}
        {[
          { label: "Quantity (kg)", key: "qty", placeholder: "e.g. 1800" },
          { label: "Expected Price (₹/kg)", key: "price", placeholder: "e.g. 142" },
          { label: "Location / Area", key: "location", placeholder: "e.g. North Industrial Zone" },
          { label: "Availability Date", key: "availability", placeholder: "e.g. Immediate / 15 Sep" },
        ].map(f => (
          <div key={f.key}>
            <label style={{ fontSize: 13, color: "#94a3b8", display: "block", marginBottom: 6 }}>{f.label}</label>
            <input value={form[f.key as keyof typeof form]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
              placeholder={f.placeholder}
              style={{ width: "100%", background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "11px 14px", color: "#e8edf5", fontSize: 14, outline: "none" }} />
          </div>
        ))}
        <div>
          <label style={{ fontSize: 13, color: "#94a3b8", display: "block", marginBottom: 6 }}>Photo (optional)</label>
          <div style={{ border: "1px dashed rgba(255,255,255,0.12)", borderRadius: 8, padding: "20px", textAlign: "center", color: "#4b5563", fontSize: 13, cursor: "pointer" }}>📷 Click to upload photo</div>
        </div>
        <button type="submit" className="btn-primary" style={{ width: "100%", justifyContent: "center", fontSize: 15, padding: "14px" }}>POST MATERIAL</button>
      </form>
    </div>
  );
}

// ─── CREATE DEMAND ────────────────────────────────────────────────────────────

function CreateDemandPage({ onNav }: { onNav: (page: string) => void }) {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ material: "Aluminium Scrap", qty: "5000", grade: "Grade B+", price: "148", deadline: "2026-09-20", location: "North Manufacturing Cluster", budget: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div style={{ padding: "32px 0", maxWidth: 520, margin: "0 auto" }}>
        <div style={{ background: "rgba(124,58,237,0.08)", border: "1px solid rgba(124,58,237,0.25)", borderRadius: 16, padding: 32, textAlign: "center" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>✦</div>
          <div className="badge badge-purple" style={{ marginBottom: 12 }}>AI SOURCING ACTIVE</div>
          <div style={{ fontFamily: "Outfit", fontSize: 24, fontWeight: 800, marginBottom: 8 }}>Demand Activated</div>
          <div style={{ color: "#94a3b8", marginBottom: 24 }}>ReLoop AI is now actively sourcing {form.material} across the network</div>
          <button className="btn-ai" style={{ width: "100%", justifyContent: "center" }} onClick={() => onNav("optimizer")}>✦ Run Full Optimizer</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: "32px 0", maxWidth: 520, margin: "0 auto" }}>
      <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>Create Demand</div>
      <div style={{ color: "#64748b", fontSize: 14, marginBottom: 24 }}>Define what you need — ReLoop AI will activate sourcing immediately</div>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        <div>
          <label style={{ fontSize: 13, color: "#94a3b8", display: "block", marginBottom: 6 }}>Material</label>
          <select value={form.material} onChange={e => setForm(p => ({ ...p, material: e.target.value }))}
            style={{ width: "100%", background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "11px 14px", color: "#e8edf5", fontSize: 14 }}>
            {["Aluminium Scrap", "Copper", "PET Plastic", "Paper", "Glass", "Textile Waste"].map(o => <option key={o}>{o}</option>)}
          </select>
        </div>
        {[
          { label: "Quantity Required (kg)", key: "qty", placeholder: "e.g. 5000" },
          { label: "Target Price (₹/kg)", key: "price", placeholder: "e.g. 148" },
          { label: "Required By (date)", key: "deadline", type: "date" },
          { label: "Delivery Location", key: "location", placeholder: "e.g. North Manufacturing Cluster" },
          { label: "Logistics Budget (₹)", key: "budget", placeholder: "e.g. 5000" },
        ].map(f => (
          <div key={f.key}>
            <label style={{ fontSize: 13, color: "#94a3b8", display: "block", marginBottom: 6 }}>{f.label}</label>
            <input
              type={f.type || "text"}
              value={form[f.key as keyof typeof form]}
              onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
              placeholder={f.placeholder}
              style={{ width: "100%", background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "11px 14px", color: "#e8edf5", fontSize: 14, outline: "none", colorScheme: "dark" }}
            />
          </div>
        ))}
        <div>
          <label style={{ fontSize: 13, color: "#94a3b8", display: "block", marginBottom: 6 }}>Minimum Quality</label>
          <select value={form.grade} onChange={e => setForm(p => ({ ...p, grade: e.target.value }))}
            style={{ width: "100%", background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "11px 14px", color: "#e8edf5", fontSize: 14 }}>
            {["Grade A", "Grade B+", "Grade B", "Grade C"].map(o => <option key={o}>{o}</option>)}
          </select>
        </div>
        <button type="submit" className="btn-ai" style={{ width: "100%", justifyContent: "center", fontSize: 15, padding: "14px" }}>✦ ACTIVATE AI SOURCING</button>
      </form>
    </div>
  );
}

// ─── AI ENGINE PAGE ───────────────────────────────────────────────────────────

function AIEnginePage() {
  const pipeline = [
    { step: "LISTINGS", desc: "Supply and demand listings collected from all network nodes", color: "#60a5fa", details: ["Material type", "Quality grade", "Quantity", "Location", "Price", "Urgency"] },
    { step: "MATERIAL UNDERSTANDING", desc: "AI interprets material attributes and classifies compatibility", color: "#a78bfa", details: ["Type classification", "Grade normalization", "Quantity validation", "Location geocoding"] },
    { step: "SUPPLY-DEMAND MATCHING", desc: "Cross-match all supply entries against all active demands", color: "#7c3aed", details: ["Supply ↔ Demand", "Material type match", "Grade threshold check", "Quantity feasibility"] },
    { step: "FEASIBILITY FILTER", desc: "Eliminate infeasible combinations — distance, deadline, grade", color: "#f59e0b", details: ["Distance constraint", "Deadline constraint", "Grade constraint", "Minimum quantity"] },
    { step: "LP / MILP ALLOCATION", desc: "Minimize total landed cost subject to supply/demand/capacity constraints", color: "#10b981", details: ["Supplier selection", "Quantity allocation", "Aggregation decision", "Cost minimization"] },
    { step: "ROUTE OPTIMIZATION", desc: "Optimal pickup sequence given vehicle capacity and time windows", color: "#34d399", details: ["Pickup sequence", "Vehicle capacity", "Distance minimization", "Deadline adherence"] },
    { step: "EXECUTION PLAN", desc: "Actionable plan delivered to all parties — suppliers, collection partners, buyers", color: "#10b981", details: ["Collection schedule", "Transport manifest", "Delivery confirmation", "Settlement trigger"] },
  ];

  return (
    <div style={{ padding: "32px 0" }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontFamily: "Outfit", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>RELOOP AI ENGINE</div>
        <div style={{ color: "#64748b", fontSize: 14 }}>What happens inside ReLoop — from listing to execution</div>
        <div className="badge badge-purple" style={{ marginTop: 8 }}>AI Decision Engine • Prototype Simulation</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
        {/* Pipeline */}
        <div>
          {pipeline.map((stage, i) => (
            <div key={stage.step} style={{ display: "flex", gap: 16, marginBottom: i < pipeline.length - 1 ? 4 : 0 }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                <div style={{ width: 36, height: 36, borderRadius: "50%", background: `${stage.color}20`, border: `2px solid ${stage.color}60`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 800, color: stage.color, flexShrink: 0 }}>{i + 1}</div>
                {i < pipeline.length - 1 && <div style={{ width: 2, flex: 1, minHeight: 24, background: `linear-gradient(to bottom, ${stage.color}50, ${pipeline[i + 1].color}30)` }} />}
              </div>
              <div style={{ paddingBottom: i < pipeline.length - 1 ? 20 : 0, flex: 1 }}>
                <div style={{ background: `${stage.color}08`, border: `1px solid ${stage.color}20`, borderRadius: 10, padding: "12px 16px" }}>
                  <div style={{ fontFamily: "JetBrains Mono", fontSize: 11, color: stage.color, fontWeight: 700, marginBottom: 4, letterSpacing: 0.5 }}>{stage.step}</div>
                  <div style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.5, marginBottom: 10 }}>{stage.desc}</div>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    {stage.details.map(d => <span key={d} className="badge badge-gray" style={{ fontSize: 10 }}>{d}</span>)}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Why it matters */}
        <div>
          <div style={{ background: "rgba(12,20,40,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 24, marginBottom: 16 }}>
            <div style={{ fontFamily: "Outfit", fontSize: 18, fontWeight: 800, marginBottom: 16 }}>Why ReLoop is Different</div>
            {[
              { icon: "◫", title: "Not just a marketplace", desc: "Listings alone don't solve logistics, aggregation, or allocation. ReLoop does." },
              { icon: "⬡", title: "Solves the allocation problem", desc: "LP/MILP optimization finds the globally best supplier combination — not just the first match." },
              { icon: "⟳", title: "Optimizes logistics end-to-end", desc: "Route optimization + vehicle capacity + pickup sequencing — reducing logistics cost by 31%." },
              { icon: "✦", title: "Explainable decisions", desc: "Every choice has a reason. ReLoop shows you why each supplier was selected or rejected." },
            ].map(d => (
              <div key={d.title} style={{ display: "flex", gap: 12, padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                <div style={{ width: 36, height: 36, borderRadius: 8, background: "rgba(124,58,237,0.15)", border: "1px solid rgba(124,58,237,0.25)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>{d.icon}</div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 3 }}>{d.title}</div>
                  <div style={{ fontSize: 13, color: "#64748b", lineHeight: 1.5 }}>{d.desc}</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ background: "linear-gradient(135deg, rgba(16,185,129,0.08), rgba(124,58,237,0.08))", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 12, padding: 20 }}>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 13, color: "#7c3aed", fontStyle: "italic", lineHeight: 1.8, textAlign: "center" }}>
              "ReLoop is not another waste marketplace.<br />
              It is an intelligent coordination<br />and optimization layer<br />for the circular economy."
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── SIDEBAR ──────────────────────────────────────────────────────────────────

function Sidebar({ page, onNav }: { page: string; onNav: (p: string) => void }) {
  return (
    <div style={{ width: 220, flexShrink: 0, background: "rgba(6, 13, 31, 0.95)", borderRight: "1px solid rgba(255,255,255,0.05)", display: "flex", flexDirection: "column", height: "100vh", position: "sticky", top: 0, overflow: "hidden" }}>
      {/* Logo */}
      <div style={{ padding: "24px 16px 16px", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg, #10b981, #7c3aed)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>♻</div>
          <div style={{ fontFamily: "Outfit", fontSize: 20, fontWeight: 900, letterSpacing: "-0.01em" }}>RELOOP</div>
        </div>
        <div style={{ fontSize: 11, color: "#4b5563", fontFamily: "JetBrains Mono", paddingLeft: 42 }}>Turn Waste Into Value</div>
      </div>

      {/* Top controls */}
      <div style={{ padding: "12px 12px 8px" }}>
        <div style={{ display: "flex", gap: 4 }}>
          {["Supply", "Demand", "Network"].map(t => (
            <button key={t} onClick={() => onNav(t === "Supply" ? "addmaterial" : t === "Demand" ? "createdemand" : "network")}
              style={{ flex: 1, padding: "6px 4px", borderRadius: 6, border: "1px solid rgba(255,255,255,0.07)", background: "rgba(12,20,40,0.8)", color: "#64748b", fontSize: 11, cursor: "pointer", fontWeight: 600, transition: "all 0.2s" }}
              onMouseEnter={e => { (e.target as HTMLElement).style.color = "#10b981"; (e.target as HTMLElement).style.borderColor = "rgba(16,185,129,0.3)"; }}
              onMouseLeave={e => { (e.target as HTMLElement).style.color = "#64748b"; (e.target as HTMLElement).style.borderColor = "rgba(255,255,255,0.07)"; }}>
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: "4px 8px", overflowY: "auto" }}>
        {NAV_ITEMS.map(item => (
          <div key={item.id} className={`nav-item ${page === item.id ? "active" : ""}`} onClick={() => onNav(item.id)}>
            <span style={{ fontSize: 14, width: 20, textAlign: "center", flexShrink: 0 }}>{item.icon}</span>
            <span>{item.label}</span>
          </div>
        ))}
        <div style={{ height: 8 }} />
        <div style={{ fontSize: 11, color: "#4b5563", padding: "4px 12px", fontFamily: "JetBrains Mono", letterSpacing: 0.5 }}>WORKSPACES</div>
        {[{ id: "engine", label: "AI Engine", icon: "◎" }, { id: "addmaterial", label: "Add Material", icon: "+" }, { id: "createdemand", label: "Create Demand", icon: "+" }].map(item => (
          <div key={item.id} className={`nav-item ${page === item.id ? "active" : ""}`} onClick={() => onNav(item.id)}>
            <span style={{ fontSize: 14, width: 20, textAlign: "center", flexShrink: 0 }}>{item.icon}</span>
            <span>{item.label}</span>
          </div>
        ))}
      </nav>

      {/* User */}
      <div style={{ padding: "12px 16px", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg, #10b981, #7c3aed)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700 }}>EM</div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>EcoMetal Recycling</div>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <span className="badge badge-green" style={{ fontSize: 9 }}>✓ Verified</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── TOPBAR ───────────────────────────────────────────────────────────────────

function TopBar({ page }: { page: string }) {
  const labels: Record<string, string> = {
    home: "Dashboard", marketplace: "Marketplace", opportunities: "AI Opportunity Radar",
    optimizer: "Optimization Engine", logistics: "Logistics", price: "Price Intelligence",
    network: "Network", transactions: "Transactions", impact: "Impact Dashboard",
    engine: "AI Engine", addmaterial: "Add Material", createdemand: "Create Demand",
  };

  return (
    <div style={{ height: 56, background: "rgba(6,13,31,0.9)", borderBottom: "1px solid rgba(255,255,255,0.05)", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 24px", backdropFilter: "blur(8px)", position: "sticky", top: 0, zIndex: 100 }}>
      <div style={{ fontFamily: "Outfit", fontSize: 16, fontWeight: 700, color: "#94a3b8" }}>{labels[page] || page}</div>
      <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
        <div className="badge badge-green animate-pulse-green" style={{ fontSize: 11 }}>● NETWORK LIVE</div>
        <div style={{ fontSize: 13, color: "#64748b" }}>5,700 kg available</div>
        <div style={{ fontSize: 13, color: "#64748b" }}>₹18.4L network value</div>
      </div>
    </div>
  );
}

// ─── APP ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [page, setPage] = useState("home");

  const onNav = useCallback((p: string) => {
    setPage(p);
    window.scrollTo(0, 0);
  }, []);

  const renderPage = () => {
    switch (page) {
      case "home": return <HomePage onNav={onNav} />;
      case "marketplace": return <MarketplacePage onNav={onNav} />;
      case "opportunities": return <OpportunitiesPage onNav={onNav} />;
      case "optimizer": return <OptimizerPage />;
      case "logistics": return <LogisticsPage />;
      case "price": return <PricePage />;
      case "network": return <NetworkPage />;
      case "transactions": return <TransactionsPage />;
      case "impact": return <ImpactPage />;
      case "engine": return <AIEnginePage />;
      case "addmaterial": return <AddMaterialPage />;
      case "createdemand": return <CreateDemandPage onNav={onNav} />;
      default: return <HomePage onNav={onNav} />;
    }
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#060d1f" }}>
      <Sidebar page={page} onNav={onNav} />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        <TopBar page={page} />
        <main style={{ flex: 1, padding: "0 32px 40px", maxWidth: 1200, width: "100%" }}>
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
